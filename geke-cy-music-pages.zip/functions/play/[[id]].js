function escapeHtml(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function generatePlayPage(data, songId) {
  const hasData = data && data.title;
  const songName = hasData ? data.title : '未知歌曲';
  const artistName = hasData ? (data.artist || '未知歌手') : '';
  const mp3Url = hasData ? (data.link || '') : '';
  const coverUrl = hasData ? (data.cover || 'https://img2.kuwo.cn/star/albumcover/500/s4s86/95/3059703046.jpg') : 'https://img2.kuwo.cn/star/albumcover/500/s4s86/95/3059703046.jpg';
  const lrcText = hasData ? (data.lyric || '') : '';
  const pageTitle = hasData ? `${songName}-${artistName}-MP3播放-GeKeCy-music` : '歌曲播放 - GeKeCy-music';
  const downloadMp3Href = mp3Url || 'javascript:void(0)';

  let lyricsHtml = '';
  if (lrcText) {
    const lines = lrcText.split('\n');
    const plainLyrics = [];
    for (const line of lines) {
      const textPart = line.replace(/\[\d{2}:\d{2}(\.\d{2,3})?\]/g, '').trim();
      if (textPart) plainLyrics.push(escapeHtml(textPart));
    }
    lyricsHtml = `
<div class="card shadow-sm mb-3">
    <div class="card-body">
        <div style="display: block">
            <div class="content-lrc mt-1" id="content-lrc">${plainLyrics.join('<br>')}</div>
        </div>
        <div class="expand" data-status="up" onclick="var c=document.getElementById('content-lrc');var e=this;if(e.dataset.status==='up'){c.style.maxHeight='unset';e.dataset.status='down';e.textContent='收起';}else{c.style.maxHeight='21rem';e.dataset.status='up';e.textContent='查看全部';}">查看全部</div>
        <br>
        <div class="quote-warning mb-4">
            <i class="fa fa-info-circle"></i>
            如在线播放和下载错误，请更换浏览器刷新重试。
        </div>
    </div>
</div>`;
  }

  const lrcJsString = lrcText ? lrcText.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/\$/g, '\\$').replace(/\n/g, '\\n').replace(/\r/g, '') : '';

  const playerContent = hasData ? `
    <div id="player-area">
        <div id="aplayer" class="aplayer aplayer-withlrc"></div>
        <br>
        <div class="input-group mb-1 overflow-hidden" style="margin-bottom: 0.9rem !important;">
            <div class="input-group-prepend">
                <i class="fa fa-music input-group-text" style="color: #ffffff;background-color: #31c27c !important;border: 1px solid #31c27c;padding: .55rem .75rem;border-radius: 0;"></i>
            </div>
            <h1 class="form-control bg-light nowrap-hidden" style="color: #ffffff;background-color: #31c27c !important;border: 1px solid #31c27c;">${escapeHtml(songName)}-${escapeHtml(artistName)}.mp3</h1>
            <div class="input-group-append">
                <a id="btn-download-mp3" class="btn btn-custom" href="${escapeHtml(downloadMp3Href)}" target="_blank">
                    <i class="fa fa-download"></i>
                    <span class="download-text">下载歌曲</span>
                </a>
            </div>
        </div>
        <div class="input-group overflow-hidden">
            <div class="input-group-prepend">
                <i class="fa fa-file-text-o input-group-text" style="color: #ffffff; background-color: #31c27c !important;border: 1px solid #31c27c;padding: .55rem .75rem;border-radius: 0;"></i>
            </div>
            <h2 class="form-control bg-light nowrap-hidden" style="color: #ffffff;background-color: #31c27c !important;border: 1px solid #31c27c;">
                ${escapeHtml(songName)}-${escapeHtml(artistName)}-歌词.lrc
            </h2>
            <div class="input-group-append">
                <a id="btn-download-lrc" class="btn btn-custom" href="javascript:void(0)">
                    <i class="fa fa-download"></i>
                    <span class="download-text">下载歌词</span>
                </a>
            </div>
        </div>
    </div>` : `
    <div class="error-box">
        <i class="fa fa-exclamation-circle"></i>
        歌曲加载失败（ID: ${escapeHtml(songId)}），请稍后再试
    </div>`;

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>${pageTitle}</title>
    <link href="/static/css/common.css" rel="stylesheet">
    <link href="//lib.baomitu.com/twitter-bootstrap/4.6.1/css/bootstrap.min.css" type="text/css" rel="stylesheet">
    <link href="//lib.baomitu.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" rel="stylesheet">
    <link href="//lib.baomitu.com/aplayer/1.10.1/APlayer.min.css" rel="stylesheet">
    <script src="//lib.baomitu.com/jquery/3.6.0/jquery.min.js" type="application/javascript"></script>
    <script defer src="//lib.baomitu.com/twitter-bootstrap/4.6.1/js/bootstrap.min.js" type="application/javascript"></script>
    <script defer src="//lib.baomitu.com/aplayer/1.10.1/APlayer.min.js" type="application/javascript"></script>
    <style>
        html, body { height: 100%; margin: 0; }
        body { display: flex; flex-direction: column; min-height: 100vh; font-family: "Microsoft YaHei", "Helvetica Neue", Helvetica, STHeiTi, sans-serif; }
        .main-content { flex: 1 0 auto; }
        .navbar-h1 { display: inline; font-size: 1.5rem; font-weight: 700; }
        .card { margin-top: 15px; position: relative; display: flex; flex-direction: column; min-width: 0; word-wrap: break-word; background-color: #fff; background-clip: border-box; border: 1px solid rgba(0, 0, 0, .125); border-radius: .5rem; font-size: 15px; }
        .btn-custom { background-color: #31c27c; border-color: #31c27c; color: white; border-radius: 0 0.25rem 0.25rem 0 !important; height: 40px; }
        .btn-custom:hover { background-color: #2ab06d; border-color: #2ab06d; }
        a { color: #333; text-decoration: none; background-color: transparent; }
        a:hover { color: #31c27c; text-decoration: underline; }
        .quote-warning { border-left: 4px solid #31c27c; background-color: #f8f9fa; padding: .5rem; color: #434343; }
        .error-box { border-left: 4px solid #ff5252; background-color: #fff5f5; padding: 1rem; color: #d32f2f; border-radius: 4px; margin: 15px 0; }

        .aplayer-container { width: 80%; max-width: 800px; position: relative; }
        .content-lrc { min-height: 21rem; max-height: 21rem; overflow: hidden; font-family: "Microsoft YaHei", sans-serif; background-color: #ffffff; line-height: 1.8; color: #555; margin-bottom: 10px; letter-spacing: 0.01em; padding-left: 5px; }
        .expand { text-align: center; cursor: pointer; color: #009688; }
        .height-auto { max-height: unset; }
        .nowrap-hidden { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .aplayer-notice { z-index: 2; }
        .aplayer .aplayer-lrc p.aplayer-lrc-current { color: #FF6666; opacity: 1; overflow: visible; height: auto !important; min-height: 16px; }
        @media (min-width: 768px) { .aplayer .aplayer-lrc p.aplayer-lrc-current { font-size: 17px; } }
        @media (max-width: 767.98px) { .aplayer .aplayer-lrc p.aplayer-lrc-current { font-size: 14px; } }
        .aplayer .aplayer-lrc p { font-weight: 700; font-size: 13px; color: #777; line-height: 21px !important; height: 16px !important; padding: 0 !important; margin: 0 !important; transition: all 0.5s ease-out; opacity: .4; overflow: hidden; }
        .aplayer-pic { transition: transform 2s linear infinite; }
        .aplayer-pic.rotating { animation: rotate 30s linear infinite; }
        @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        .aplayer .aplayer-pic .aplayer-pause { display: none; width: 16px; height: 16px; border: 2px solid #fff; bottom: 40%; right: 40%; }
        .aplayer.aplayer-withlrc .aplayer-pic { height: 74px; width: 74px; border-radius: 50%; margin: 19px; position: relative; z-index: 2; }
        .aplayer::before { content: ""; position: absolute; width: 112px; height: 112px; background-image: url("/static/img/play.png"); background-size: cover; background-repeat: no-repeat; border-radius: 50%; z-index: 2; pointer-events: none; animation: none !important; }
        .aplayer { background: #ffffff; font-family: Arial, Helvetica, sans-serif; margin: 0px; box-shadow: 0 0 0 0 rgba(0,0,0,.07), 0 0 0 0 rgba(0,0,0,.1); border-radius: 43px 10px 10px 43px; overflow: hidden; -webkit-user-select: none; user-select: none; line-height: normal; position: relative; }
        .aplayer.aplayer-withlrc .aplayer-info { margin-left: 120px; height: 90px; padding: 5px 0px 0; }
        .aplayer .aplayer-lrc { display: none; position: relative; height: 38px; text-align: center; overflow: hidden; margin: 9px 0 13px; }
        .aplayer .aplayer-info .aplayer-music { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; margin: 6px 0 6px 12px; user-select: text; cursor: default; padding-bottom: 2px; height: 20px; }
        .aplayer .aplayer-lrc:before { top: 0; height: 5%; background: linear-gradient(180deg, #fff 0, hsla(0,0%,100%,0)); }
        .aplayer-author a { text-decoration: none; color: inherit; }
        .download-button { background-color: #31c27c !important; color: white !important; border: none !important; }

        footer {
            flex-shrink: 0; background-color: #343a40; color: #999;
            padding: 40px 0 20px 0; margin-top: auto;
        }
        footer a { color: #ccc; }
        footer a:hover { color: #31c27c; }
        .footer-links { margin: 10px 0; }
        .footer-links a { margin: 0 10px; font-size: 13px; }
    </style>
</head>
<body>
<div class="main-content">
<div class="container" style="max-width: 900px">
    <nav class="navbar navbar-light bg-white px-0 mb-1 font-weight-normal">
        <a class="navbar-brand font-weight-bolder" style="font-size: 1.5rem; color: #50514F;" href="/">
            <h1 class="navbar-h1">GeKeCy-music</h1>
        </a>
    </nav>

    <div class="row mb-2"></div>

    <div class="card shadow-sm mb-3">
        <div class="card-body">
            ${playerContent}
        </div>
    </div>

    ${lyricsHtml}
</div>
</div>

<footer>
    <div class="container" style="max-width: 900px;">
        <div class="text-center">
            <a href="/" class="font-weight-bold" style="font-size:18px;color:#fff;">GeKeCy-music</a>
            <div class="footer-links">
                <a href="/">首页</a>
                <a href="https://github.com/GeKeCy/GeKeCy_Music.github.io" target="_blank">GitHub</a>
            </div>
            <div style="font-size:12px;color:#666;margin-top:10px;">
                GeKeCy-music &copy; 2026 &middot; 仅供学习交流使用
            </div>
        </div>
    </div>
</footer>

<script type="text/javascript">
window.onload = function() {
    var apContainer = document.getElementById('aplayer');
    if (apContainer && typeof APlayer !== 'undefined') {
        window.ap = new APlayer({
            container: apContainer,
            autoplay: false,
            theme: '#FF5555',
            lrcType: 3,
            preload: 'metadata',
            loop: 'none',
            order: 'list',
            volume: 0.5,
            audio: [{
                name: ${JSON.stringify(songName)},
                artist: ${JSON.stringify(artistName)},
                url: ${JSON.stringify(mp3Url)},
                cover: ${JSON.stringify(coverUrl)},
                lrc: \`${lrcJsString}\`,
                theme: '#FF5555'
            }]
        });
        var cover = document.querySelector('.aplayer-pic');
        if (cover) {
            ap.on('play', function() { cover.classList.add('rotating'); });
            ap.on('pause', function() { cover.classList.remove('rotating'); });
        }
        if (!${JSON.stringify(mp3Url)}) {
            setTimeout(function() {
                if (ap) {
                    ap.notice('<span style="color:#FF5722;font-weight:bold"><i class="fa fa-exclamation-circle"></i> 无法获取播放链接，可能是网络问题或该歌曲需要VIP</span>', 5000, 1);
                }
            }, 1000);
        }
    }

    var btnDownloadLrc = document.getElementById('btn-download-lrc');
    if (btnDownloadLrc) {
        btnDownloadLrc.addEventListener('click', function(e) {
            e.preventDefault();
            var lrcText = \`${lrcJsString}\`;
            var blob = new Blob([lrcText], { type: 'text/plain;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = ${JSON.stringify(songName + '-' + artistName + '-歌词.lrc')};
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }
};
</script>
</body>
</html>`;
}

export async function onRequest(context) {
  const songId = context.params.id || '';

  if (!songId) {
    return Response.redirect(new URL(context.request.url).origin + '/', 302);
  }

  let data = null;
  try {
    const res = await fetch(
      `https://api.paugram.com/netease/?id=${encodeURIComponent(songId)}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      }
    );
    data = await res.json();
  } catch (e) {
    data = null;
  }

  const html = generatePlayPage(data, songId);
  return new Response(html, {
    headers: { 'Content-Type': 'text/html; charset=utf-8' }
  });
}
